# Examples for PS2EXE

## Generate examples

In Powershell execute
```powershell
.\BuildExamples.ps1
```

In Cmd execute
```cmd
.\BuildExamples.bat
```

The examples with "-GUI" in name are compiled with flag -NoConsole, the other ones without.
