Markus Scholtes, 2016


Admin-Explorer.ps1

contains the following functions:
AdminExplorer (administrative File Open dialogue as replacement for administrative Windows Explorer)
Select-FileDialog (starts a "File Open" or "Save As" dialogue)
Test-Admin (checks whether the current Powershell runs in administrative mode)
Start-Elevated (starts a program with administrative privileges)
Start-ElevatedPowerShell (starts an administrative powershell)
su (alias for Start-Elevated)
sudo (alias for Start-Elevated)


Admin-Explorer - profile.ps1

AdminExplorer for use in a powershell profile